import Main from './containers/Main'
import React, { Component } from 'react'
import { store, persistor} from './redux/store'
import {Provider} from 'react-redux'
import { PersistGate } from 'redux-persist/es/integration/react'

export default class App extends Component {
  render() {
    return (
      <Provider store={store}>
        <PersistGate loading={null} persistor={persistor}>
          <Main />
        </PersistGate>
      </Provider>
    );
  }
}
