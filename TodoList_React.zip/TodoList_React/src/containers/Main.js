import React, { Component } from "react";
import { connect } from "react-redux";
import TodoItem from "../components/TodoItem/TodoItem";
import AddToDo from "../components/AddToDo/AddToDo";
import styles from "./Main.style";
import { addTask, deleteTask, completeTask } from "../redux/actions";

export class Main extends Component {
  render() {
    console.log("redux todos: " + this.props.taskItems);
    return (
      <div style={styles.appContainer}>
        <div style={styles.container}>
          <h1 styles={styles.title}>Todo List</h1>
          <div style={styles.inputWrapper}>
            <AddToDo
              addTodo={(task) => {
                this.props.addTodo(task);
              }}
            />
            <hr style={styles.separator} />
          </div>
          {this.props.taskItems.map((task) => {
            return (
              <TodoItem
                task={task}
                deleteTodo={(task) => this.props.deleteTodo(task)}
                completeTodo={(task) => this.props.completeTodo(task)}
              />
            );
          })}
        </div>
      </div>
    );
  }
}

const mapStateToProps = (state) => ({
  taskItems: state.taskItems,
});

const mapDispatchToProps = (dispatch) => ({
  addTodo: (task) => dispatch(addTask(task)),
  deleteTodo: (task) => dispatch(deleteTask(task)),
  completeTodo: (task) => dispatch(completeTask(task)),
});

export default connect(mapStateToProps, mapDispatchToProps)(Main);
